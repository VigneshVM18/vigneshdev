
import React, { useEffect, useState } from 'react';
import { Calendar, MapPin, Building, Code, Database, Palette, Monitor, Settings, Terminal, Zap } from 'lucide-react';
import CodeAnimation3D from './CodeAnimation3D';

const Experience = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const experienceSection = document.getElementById('experience');
    if (experienceSection) {
      observer.observe(experienceSection);
    }

    return () => observer.disconnect();
  }, []);

  const experiences = [
    {
      title: 'Property Find - Real Estate Listing Web Application',
      company: 'Axxxxmun Business Solution',
      period: 'Feb 2023 – Present',
      type: 'Project',
      location: 'Remote',
      description: 'Employee Timesheet Tracker - The purpose of Property Find is to develop a modern, fully responsive real estate website that allows users to browse, search, and filter property listings.',
      achievements: [
        'Designed responsive UI layout using Tailwind CSS, ensuring optimal experience across devices',
        'Developed reusable React components such as Property Card, Search Bar, Filter Panel, and Modal',
        'Implemented client-side routing using React Router to navigate between Home, Listings, and Details pages',
        'Created a dynamic search and filter system (location, price range, property type) using React state and JavaScript logic',
        'Built an interactive property details page with image galleries, feature highlights, and contact buttons',
        'Integrated form validation and modals for user inquiries using JavaScript and controlled components in React',
        'Optimized the performance by code splitting and lazy loading components'
      ],
      gradient: 'from-blue-500 to-cyan-600',
      color: 'text-blue-600'
    },
    {
      title: 'Employee Timesheet Tracker',
      company: 'Professional Experience',
      period: 'Jan 2022 – Feb 2023',
      type: 'Project',
      location: 'Remote',
      description: 'Created a web-based timesheet tracker for internal HR to log, view, and analyze employee working hours.',
      achievements: [
        'Designed clean UI using Bootstrap, CSS Grid, and JavaScript for time input and reporting',
        'Built backend in SQL Server with complex queries for leave balance, overtime, and absence analysis',
        'Implemented data export to Excel and PDF',
        'Integrated charting tools to visualize employee productivity using Chart.js'
      ],
      gradient: 'from-purple-500 to-pink-600',
      color: 'text-purple-600'
    }
  ];

  const technicalSkills = [
    {
      category: 'Frontend Development',
      skills: ['React.js', 'JavaScript (ES6+)', 'HTML5 & CSS3', 'Tailwind CSS', 'Bootstrap'],
      icon: Code,
      color: 'text-blue-600',
      bgGradient: 'from-blue-500/10 to-cyan-500/10',
      borderColor: 'border-blue-200/50 hover:border-blue-300'
    },
    {
      category: 'Backend & Database',
      skills: ['SQL Server', 'MySQL', 'REST API Integration', 'JSON Processing'],
      icon: Database,
      color: 'text-emerald-600',
      bgGradient: 'from-emerald-500/10 to-teal-500/10',
      borderColor: 'border-emerald-200/50 hover:border-emerald-300'
    },
    {
      category: 'Development Tools',
      skills: ['Visual Studio Code', 'Git & GitHub', 'Chrome DevTools', 'NPM/Yarn'],
      icon: Terminal,
      color: 'text-purple-600',  
      bgGradient: 'from-purple-500/10 to-indigo-500/10',
      borderColor: 'border-purple-200/50 hover:border-purple-300'
    },
    {
      category: 'Design & UI/UX',
      skills: ['Figma', 'Responsive Design', 'UI Component Libraries', 'User Experience Design'],
      icon: Palette,
      color: 'text-pink-600',
      bgGradient: 'from-pink-500/10 to-rose-500/10',
      borderColor: 'border-pink-200/50 hover:border-pink-300'
    },
    {
      category: 'Data Visualization',
      skills: ['Chart.js', 'Data Analysis', 'Excel Integration', 'PDF Generation'],
      icon: Settings,
      color: 'text-orange-600',
      bgGradient: 'from-orange-500/10 to-amber-500/10',
      borderColor: 'border-orange-200/50 hover:border-orange-300'
    },
    {
      category: 'No-Code Platforms',
      skills: ['Lovable', 'Webflow', 'Framer', 'Rapid Prototyping'],
      icon: Zap,
      color: 'text-indigo-600',
      bgGradient: 'from-indigo-500/10 to-violet-500/10',
      borderColor: 'border-indigo-200/50 hover:border-indigo-300'
    }
  ];

  return (
    <section id="experience" className="py-32 bg-gray-50 relative overflow-hidden">
      {/* 3D Code Animation */}
      <CodeAnimation3D variant="experience" />
      
      {/* Subtle background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 right-1/3 w-96 h-96 bg-gray-200/30 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 left-1/3 w-80 h-80 bg-gray-300/20 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-8 relative z-10">
        <div className={`transform transition-all duration-1000 ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
        }`}>
          <div className="text-center mb-24">
            <h2 className="text-6xl md:text-7xl font-thin text-gray-900 mb-8 tracking-tight">
              Professional <span className="text-gray-600">Journey</span>
            </h2>
            <div className="w-20 h-px bg-gray-400 mx-auto mb-8"></div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto font-light leading-relaxed">
              Building modern, responsive solutions with a focus on exceptional user experience
            </p>
          </div>

          {/* Professional Experience */}
          <div className="mb-20">
            <h3 className="text-3xl font-light text-gray-900 mb-12 text-center">Professional Experience</h3>
            <div className="space-y-12">
              {experiences.map((exp, index) => (
                <div
                  key={exp.title}
                  className={`group relative bg-white/80 backdrop-blur-sm rounded-3xl p-12 border border-gray-200/50 hover:border-gray-300/50 transition-all duration-700 hover:shadow-2xl hover:shadow-gray-900/5 transform hover:-translate-y-2 ${
                    isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
                  }`}
                  style={{ transitionDelay: `${index * 200}ms` }}
                >
                  {/* Enhanced gradient accent line */}
                  <div className={`absolute left-0 top-0 w-1 h-full bg-gradient-to-b ${exp.gradient} rounded-l-3xl opacity-60 group-hover:opacity-100 transition-opacity duration-300`}></div>
                  
                  {/* Subtle hover effect */}
                  <div className="absolute inset-0 bg-gradient-to-br from-gray-50/50 to-transparent opacity-0 group-hover:opacity-100 rounded-3xl transition-opacity duration-500"></div>
                  
                  <div className="relative z-10">
                    <div className="flex flex-col md:flex-row md:items-center justify-between mb-8">
                      <div className="mb-4 md:mb-0">
                        <div className="flex items-center gap-3 mb-3">
                          <div className={`p-2 rounded-lg bg-gray-100 group-hover:bg-white transition-colors duration-300`}>
                            <Building className={`w-5 h-5 ${exp.color}`} />
                          </div>
                          <span className="text-gray-600 font-medium">{exp.company}</span>
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${exp.color} bg-gray-100 group-hover:bg-white transition-colors duration-300`}>
                            {exp.type}
                          </span>
                        </div>
                        <h3 className="text-2xl font-light text-gray-900 mb-2 group-hover:text-gray-700 transition-colors duration-300">
                          {exp.title}
                        </h3>
                      </div>
                      <div className="flex flex-col items-start md:items-end gap-2">
                        <div className="flex items-center text-gray-500 text-sm">
                          <Calendar className="w-4 h-4 mr-2" />
                          {exp.period}
                        </div>
                        <div className="flex items-center text-gray-500 text-sm">
                          <MapPin className="w-4 h-4 mr-2" />
                          {exp.location}
                        </div>
                      </div>
                    </div>
                    
                    <p className="text-gray-600 mb-8 leading-relaxed font-light italic">
                      {exp.description}
                    </p>
                    
                    <div className="space-y-3">
                      <h4 className="text-lg font-medium text-gray-800 mb-4">Key Responsibilities and Contributions:</h4>
                      <ul className="space-y-3">
                        {exp.achievements.map((achievement, idx) => (
                          <li key={idx} className="flex items-start text-gray-600 leading-relaxed">
                            <div className={`w-1.5 h-1.5 bg-gradient-to-r ${exp.gradient} rounded-full mr-4 mt-2.5 flex-shrink-0`}></div>
                            <span className="font-light">{achievement}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Enhanced Technical Skills */}
          <div className="relative">
            <div className="text-center mb-16">
              <h3 className="text-4xl font-light text-gray-900 mb-6">Technical Expertise</h3>
              <div className="w-16 h-px bg-gradient-to-r from-transparent via-gray-400 to-transparent mx-auto mb-6"></div>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto font-light">
                A comprehensive toolkit for building modern web applications and user experiences
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
              {technicalSkills.map((skillGroup, index) => (
                <div
                  key={skillGroup.category}
                  className={`group relative bg-gradient-to-br ${skillGroup.bgGradient} backdrop-blur-sm rounded-2xl p-8 border ${skillGroup.borderColor} transition-all duration-500 transform hover:-translate-y-2 hover:shadow-xl ${
                    isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
                  }`}
                  style={{ transitionDelay: `${(index + 2) * 100}ms` }}
                >
                  {/* Animated background glow */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${skillGroup.bgGradient} opacity-0 group-hover:opacity-100 rounded-2xl transition-opacity duration-500`}></div>
                  
                  <div className="relative z-10">
                    <div className="flex items-center mb-6">
                      <div className={`p-4 rounded-2xl bg-white/80 group-hover:bg-white group-hover:shadow-lg transition-all duration-300 mr-4`}>
                        <skillGroup.icon className={`w-7 h-7 ${skillGroup.color} group-hover:scale-110 transition-transform duration-300`} />
                      </div>
                      <div>
                        <h4 className="text-xl font-semibold text-gray-900 group-hover:text-gray-700 transition-colors duration-300">
                          {skillGroup.category}
                        </h4>
                        <div className={`w-8 h-0.5 bg-gradient-to-r ${skillGroup.color.replace('text-', 'from-')} to-transparent mt-2 group-hover:w-12 transition-all duration-300`}></div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      {skillGroup.skills.map((skill, idx) => (
                        <div key={skill} className="flex items-center group-hover:translate-x-2 transition-transform duration-300" style={{ transitionDelay: `${idx * 50}ms` }}>
                          <div className={`w-2 h-2 bg-gradient-to-r ${skillGroup.color.replace('text-', 'from-')} to-transparent rounded-full mr-4 flex-shrink-0 group-hover:scale-125 transition-transform duration-300`}></div>
                          <span className="text-gray-700 font-medium group-hover:text-gray-900 transition-colors duration-300">
                            {skill}
                          </span>
                        </div>
                      ))}
                    </div>
                    
                    {/* Skill count indicator */}
                    <div className="mt-6 pt-4 border-t border-gray-200/50">
                      <span className={`text-sm font-medium ${skillGroup.color} opacity-70 group-hover:opacity-100 transition-opacity duration-300`}>
                        {skillGroup.skills.length} Skills
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;
