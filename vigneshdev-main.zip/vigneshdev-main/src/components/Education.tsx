import React, { useEffect, useState } from 'react';
import { GraduationCap, Calendar, Award } from 'lucide-react';

const Education = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const educationSection = document.getElementById('education');
    if (educationSection) {
      observer.observe(educationSection);
    }

    return () => observer.disconnect();
  }, []);

  const education = [
    {
      degree: 'BSc in Computer Science',
      institution: 'M.I.E.T College',
      period: 'Graduated 2021',
      status: 'Completed',
      description: 'Comprehensive foundation in computer science principles, programming methodologies, and software engineering practices.',
      highlights: ['Data Structures & Algorithms', 'Web Development Fundamentals', 'Database Management Systems', 'Software Engineering Principles'],
      icon: GraduationCap
    },
    {
      degree: 'MSc in Data Science',
      institution: 'Chandigarh University',
      period: 'Expected 2027',
      status: 'In Progress',
      description: 'Advanced studies in data science, machine learning algorithms, and statistical analysis with practical industry applications.',
      highlights: ['Machine Learning & AI', 'Statistical Analysis & Modeling', 'Data Visualization Techniques', 'Big Data Technologies & Tools'],
      icon: Award
    }
  ];

  return (
    <section id="education" className="py-24 bg-gradient-to-b from-gray-900 to-black relative overflow-hidden">
      {/* Minimal background effects */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gray-800/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-gray-700/5 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-8 relative z-10">
        <div className={`transform transition-all duration-1000 ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
        }`}>
          <div className="text-center mb-20">
            <h2 className="text-6xl md:text-7xl font-extralight text-white mb-6 tracking-tight">
              <span className="text-gray-400">Education</span>
            </h2>
            <div className="w-20 h-px bg-gray-500 mx-auto mb-8"></div>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto font-light">
              Academic excellence in computer science and data science foundations
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto">
            {education.map((edu, index) => {
              const IconComponent = edu.icon;
              return (
                <div
                  key={edu.degree}
                  className={`group relative bg-gray-800/30 backdrop-blur-sm rounded-2xl p-10 border border-gray-700/50 transform transition-all duration-700 hover:scale-105 hover:shadow-2xl hover:border-gray-600/50 ${
                    isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
                  }`}
                  style={{ transitionDelay: `${index * 300}ms` }}
                >
                  {/* Subtle hover background */}
                  <div className="absolute inset-0 bg-gray-700/10 opacity-0 group-hover:opacity-100 rounded-2xl transition-opacity duration-500"></div>
                  
                  <div className="relative z-10">
                    {/* Header with icon and status */}
                    <div className="flex items-center justify-between mb-8">
                      <div className="w-16 h-16 bg-gray-700 rounded-xl flex items-center justify-center transform group-hover:scale-110 transition-all duration-300 border border-gray-600">
                        <IconComponent className="w-8 h-8 text-gray-300" />
                      </div>
                      <div className="px-4 py-2 bg-gray-700 rounded-lg text-gray-300 text-sm font-light border border-gray-600">
                        {edu.status}
                      </div>
                    </div>
                    
                    {/* Degree and institution */}
                    <div className="text-center mb-8">
                      <h3 className="text-2xl font-light text-white mb-3 group-hover:text-gray-200 transition-colors duration-300">
                        {edu.degree}
                      </h3>
                      <p className="text-lg text-gray-300 font-light">{edu.institution}</p>
                      <div className="flex items-center justify-center text-gray-400 mt-3">
                        <Calendar className="w-4 h-4 mr-2" />
                        <span className="font-light">{edu.period}</span>
                      </div>
                    </div>
                    
                    <p className="text-gray-400 mb-8 leading-relaxed text-center font-light">{edu.description}</p>
                    
                    {/* Highlights */}
                    <div className="space-y-4">
                      <h4 className="font-light text-white text-center mb-6">Key Areas of Study</h4>
                      <div className="grid grid-cols-1 gap-4">
                        {edu.highlights.map((highlight, highlightIndex) => (
                          <div 
                            key={highlight} 
                            className={`bg-gray-900/40 rounded-xl p-4 text-center text-sm text-gray-300 border border-gray-700/50 hover:border-gray-600/50 transition-all duration-300 transform hover:scale-105 font-light ${
                              isVisible ? 'translate-x-0 opacity-100' : 'translate-x-4 opacity-0'
                            }`}
                            style={{ transitionDelay: `${(index * 300) + (highlightIndex * 100)}ms` }}
                          >
                            <div className="w-1.5 h-1.5 bg-gray-500 rounded-full mx-auto mb-2"></div>
                            {highlight}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Education;
