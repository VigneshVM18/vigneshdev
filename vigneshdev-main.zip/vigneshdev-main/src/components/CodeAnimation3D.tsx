
import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Code2, Braces, Terminal, GitBranch, Database, Layers, Brackets, Hash } from 'lucide-react';

interface CodeAnimation3DProps {
  variant?: 'hero' | 'experience' | 'services';
}

const CodeAnimation3D = ({ variant = 'hero' }: CodeAnimation3DProps) => {
  const containerRef = useRef<HTMLDivElement>(null);

  const codeSymbols = [
    { icon: Code2, color: '#3B82F6', size: 24 },
    { icon: Braces, color: '#10B981', size: 20 },
    { icon: Terminal, color: '#F59E0B', size: 22 },
    { icon: GitBranch, color: '#EF4444', size: 18 },
    { icon: Database, color: '#8B5CF6', size: 26 },
    { icon: Layers, color: '#06B6D4', size: 20 },
    { icon: Brackets, color: '#F97316', size: 24 },
    { icon: Hash, color: '#EC4899', size: 16 }
  ];

  const codeSnippets = [
    '{ }', '</>', '[ ]', '< >', '( )', '→', '≠', '++', '--', '===', '!==', '&&', '||'
  ];

  const getAnimationConfig = () => {
    switch (variant) {
      case 'hero':
        return {
          count: 12,
          duration: [15, 25],
          scale: [0.8, 1.2],
          opacity: [0.3, 0.7]
        };
      case 'experience':
        return {
          count: 8,
          duration: [20, 30],
          scale: [0.6, 1],
          opacity: [0.2, 0.5]
        };
      case 'services':
        return {
          count: 6,
          duration: [18, 28],
          scale: [0.7, 1.1],
          opacity: [0.25, 0.6]
        };
      default:
        return {
          count: 10,
          duration: [15, 25],
          scale: [0.8, 1.2],
          opacity: [0.3, 0.7]
        };
    }
  };

  const config = getAnimationConfig();

  return (
    <div 
      ref={containerRef}
      className="absolute inset-0 pointer-events-none overflow-hidden"
      style={{ perspective: '1000px' }}
    >
      {/* 3D Floating Code Icons */}
      {Array.from({ length: config.count }).map((_, index) => {
        const symbol = codeSymbols[index % codeSymbols.length];
        const IconComponent = symbol.icon;
        
        return (
          <motion.div
            key={`icon-${index}`}
            className="absolute"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              transformStyle: 'preserve-3d'
            }}
            animate={{
              x: [0, Math.random() * 200 - 100, 0],
              y: [0, Math.random() * 200 - 100, 0],
              z: [0, Math.random() * 100 - 50, 0],
              rotateX: [0, 360],
              rotateY: [0, 360],
              rotateZ: [0, 180],
              scale: config.scale
            }}
            transition={{
              duration: config.duration[0] + Math.random() * (config.duration[1] - config.duration[0]),
              repeat: Infinity,
              ease: "easeInOut",
              delay: index * 0.5
            }}
            initial={{ opacity: 0 }}
            whileInView={{ 
              opacity: config.opacity[0] + Math.random() * (config.opacity[1] - config.opacity[0])
            }}
          >
            <motion.div
              className="relative"
              whileHover={{ scale: 1.2, z: 50 }}
              style={{
                filter: `drop-shadow(0 0 10px ${symbol.color}40)`
              }}
            >
              <IconComponent 
                size={symbol.size} 
                color={symbol.color}
                style={{
                  transform: 'translateZ(20px)'
                }}
              />
            </motion.div>
          </motion.div>
        );
      })}

      {/* 3D Code Snippets */}
      {Array.from({ length: Math.floor(config.count / 2) }).map((_, index) => {
        const snippet = codeSnippets[index % codeSnippets.length];
        const colors = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#06B6D4'];
        const color = colors[index % colors.length];
        
        return (
          <motion.div
            key={`snippet-${index}`}
            className="absolute font-mono font-bold text-lg"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              color: color,
              transformStyle: 'preserve-3d',
              textShadow: `0 0 10px ${color}40`
            }}
            animate={{
              x: [0, Math.random() * 150 - 75, 0],
              y: [0, Math.random() * 150 - 75, 0],
              rotateX: [0, 360],
              rotateY: [0, 180],
              scale: [0.8, 1.2, 0.8]
            }}
            transition={{
              duration: config.duration[0] + Math.random() * 10,
              repeat: Infinity,
              ease: "easeInOut",
              delay: index * 0.8
            }}
            initial={{ opacity: 0, z: -50 }}
            whileInView={{ 
              opacity: config.opacity[0] + Math.random() * 0.3,
              z: 0
            }}
          >
            <motion.span
              style={{ transform: 'translateZ(30px)' }}
              whileHover={{ 
                scale: 1.3, 
                z: 100,
                textShadow: `0 0 20px ${color}`
              }}
            >
              {snippet}
            </motion.span>
          </motion.div>
        );
      })}

      {/* 3D Geometric Shapes with Code Theme */}
      {Array.from({ length: 4 }).map((_, index) => (
        <motion.div
          key={`geometry-${index}`}
          className="absolute"
          style={{
            left: `${20 + index * 20}%`,
            top: `${20 + index * 15}%`,
            transformStyle: 'preserve-3d'
          }}
          animate={{
            rotateX: [0, 360],
            rotateY: [0, 360],
            rotateZ: [0, 180],
            scale: [1, 1.1, 1],
            z: [0, 50, 0]
          }}
          transition={{
            duration: 20 + index * 5,
            repeat: Infinity,
            ease: "linear"
          }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 0.1 + index * 0.05 }}
        >
          <div
            className={`w-16 h-16 border-2 ${
              index % 2 === 0 ? 'border-blue-400/30' : 'border-purple-400/30'
            } ${
              index % 3 === 0 ? 'rounded-lg' : index % 3 === 1 ? 'rounded-full' : ''
            }`}
            style={{
              transform: `translateZ(${20 + index * 10}px)`,
              background: index % 2 === 0 
                ? 'linear-gradient(45deg, rgba(59,130,246,0.1), rgba(139,92,246,0.1))' 
                : 'linear-gradient(45deg, rgba(139,92,246,0.1), rgba(59,130,246,0.1))'
            }}
          />
        </motion.div>
      ))}

      {/* Binary Code Rain Effect */}
      <div className="absolute inset-0 opacity-5">
        {Array.from({ length: 5 }).map((_, columnIndex) => (
          <motion.div
            key={`binary-${columnIndex}`}
            className="absolute top-0 font-mono text-xs text-green-500"
            style={{
              left: `${columnIndex * 20}%`,
              height: '100%'
            }}
            animate={{
              y: [-50, window.innerHeight + 50]
            }}
            transition={{
              duration: 8 + columnIndex * 2,
              repeat: Infinity,
              ease: "linear",
              delay: columnIndex * 1.5
            }}
          >
            {Array.from({ length: 20 }).map((_, bitIndex) => (
              <div key={bitIndex} className="mb-2">
                {Math.random() > 0.5 ? '1' : '0'}
              </div>
            ))}
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default CodeAnimation3D;
