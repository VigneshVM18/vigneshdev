
import React, { useEffect, useState } from 'react';
import { motion, Variants } from 'framer-motion';
import { ArrowDown, Download, Code, Palette, Monitor } from 'lucide-react';
import BatmanCursor from './BatmanCursor';
import CodeAnimation3D from './CodeAnimation3D';

const Hero = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    setIsVisible(true);
    
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const scrollToAbout = () => {
    const aboutSection = document.getElementById('about');
    aboutSection?.scrollIntoView({ behavior: 'smooth' });
  };

  const downloadCV = () => {
    const link = document.createElement('a');
    link.href = '/lovable-uploads/9adf1580-e24c-459c-a5af-512cf13d6fab.png';
    link.download = 'Vignesh_VM_CV.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Properly typed animation variants
  const containerVariants: Variants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.2
      }
    }
  };

  const itemVariants: Variants = {
    hidden: { y: 30, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring" as const,
        stiffness: 100,
        damping: 12
      }
    }
  };

  const textRevealVariants: Variants = {
    hidden: { y: 80, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring" as const,
        stiffness: 50,
        damping: 20,
        duration: 1.0
      }
    }
  };

  const floatingIcons = [
    { Icon: Code, delay: 0, x: -100, y: -50 },
    { Icon: Palette, delay: 2, x: 100, y: 30 },
    { Icon: Monitor, delay: 4, x: -80, y: 80 }
  ];

  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden px-4 sm:px-6 lg:px-8">
      {/* Custom Batman Cursor - Hidden on mobile */}
      <div className="hidden md:block">
        <BatmanCursor x={mousePosition.x} y={mousePosition.y} />
      </div>
      
      {/* 3D Code Animation Background */}
      <CodeAnimation3D variant="hero" />
      
      {/* Animated Background with Gradient */}
      <motion.div 
        className="absolute inset-0 bg-gradient-to-br from-gray-50 via-white to-gray-100"
        animate={{
          background: [
            "linear-gradient(45deg, #f9fafb, #ffffff, #f3f4f6)",
            "linear-gradient(45deg, #f3f4f6, #f9fafb, #ffffff)",
            "linear-gradient(45deg, #ffffff, #f3f4f6, #f9fafb)"
          ]
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "linear"
        }}
      />

      {/* Floating Design Elements with Parallax - Hidden on mobile for performance */}
      <div className="absolute inset-0 pointer-events-none hidden lg:block">
        {floatingIcons.map(({ Icon, delay, x, y }, index) => (
          <motion.div
            key={index}
            className="absolute opacity-10"
            style={{
              left: `${20 + Math.abs(x) / 5}%`,
              top: `${30 + Math.abs(y) / 3}%`,
            }}
            animate={{
              x: [0, x, 0],
              y: [0, y, 0],
              rotate: [0, 180, 360],
              scale: [1, 1.2, 1],
              rotateX: [0, 180, 360],
              rotateY: [0, 360, 0]
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              delay: delay,
              ease: "easeInOut"
            }}
          >
            <Icon size={60} className="text-gray-600" />
          </motion.div>
        ))}
        
        {/* Enhanced Parallax Geometric Shapes with 3D */}
        <motion.div
          className="absolute top-1/4 left-1/12 w-24 h-24 md:w-32 md:h-32 border-2 border-gray-300/30 rounded-full"
          style={{
            x: mousePosition.x * 0.02,
            y: mousePosition.y * 0.02,
            transformStyle: 'preserve-3d'
          }}
          animate={{ 
            rotate: 360,
            rotateX: [0, 360],
            rotateY: [0, 180]
          }}
          transition={{ 
            duration: 30, 
            repeat: Infinity, 
            ease: "linear" 
          }}
        />
        
        <motion.div
          className="absolute bottom-1/4 right-1/12 w-16 h-16 md:w-24 md:h-24 bg-gradient-to-br from-gray-400/10 to-gray-600/10 rounded-lg rotate-45"
          style={{
            x: mousePosition.x * -0.01,
            y: mousePosition.y * -0.01,
            transformStyle: 'preserve-3d'
          }}
          animate={{
            scale: [1, 1.1, 1],
            rotate: [45, 135, 45],
            rotateX: [0, 180, 360],
            z: [0, 50, 0]
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto w-full grid lg:grid-cols-2 gap-6 lg:gap-12 xl:gap-16 items-center z-10 mt-8 sm:mt-0">
        {/* Content Side */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="space-y-4 sm:space-y-6 lg:space-y-8 text-center lg:text-left order-2 lg:order-1"
        >
          <motion.div variants={itemVariants} className="space-y-4 sm:space-y-6">
            <motion.div 
              className="flex items-center justify-center lg:justify-start space-x-3"
              whileHover={{ scale: 1.05 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <motion.div 
                className="w-6 sm:w-8 lg:w-10 h-0.5 bg-gray-400"
                initial={{ width: 0 }}
                animate={{ width: window.innerWidth >= 1024 ? 40 : window.innerWidth >= 640 ? 32 : 24 }}
                transition={{ delay: 0.5, duration: 0.8 }}
              />
              <motion.span 
                className="text-gray-500 text-xs font-light tracking-widest uppercase"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7, duration: 0.6 }}
              >
                Front-End Developer & UI/UX Designer
              </motion.span>
            </motion.div>
            
            {/* Text Reveal Animation for Name */}
            <div className="overflow-hidden">
              <motion.h1 
                className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-thin text-gray-900 leading-tight tracking-tight"
                variants={textRevealVariants}
              >
                <motion.span 
                  className="block"
                  initial={{ y: 100 }}
                  animate={{ y: 0 }}
                  transition={{ delay: 0.8, duration: 0.8, type: "spring" }}
                >
                  Vignesh
                </motion.span>
                <motion.span 
                  className="block text-gray-600"
                  initial={{ y: 100 }}
                  animate={{ y: 0 }}
                  transition={{ delay: 1, duration: 0.8, type: "spring" }}
                >
                  VM
                </motion.span>
              </motion.h1>
            </div>
          </motion.div>
          
          <motion.p 
            className="text-sm sm:text-base text-gray-600 leading-relaxed max-w-lg mx-auto lg:mx-0 font-light px-2 lg:px-0"
            variants={itemVariants}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
          >
            Crafting exceptional digital experiences with precision, elegance, and innovative design solutions. Transforming ideas into beautiful, functional web applications.
          </motion.p>
          
          {/* Animated Skills Tags */}
          <motion.div 
            className="flex flex-wrap gap-2 pt-3 sm:pt-4 justify-center lg:justify-start px-2 lg:px-0"
            variants={containerVariants}
          >
            {['React', 'TypeScript', 'UI/UX Design', 'Responsive Design'].map((skill, index) => (
              <motion.span
                key={skill}
                className="px-3 py-2 bg-gray-100 text-gray-700 rounded-full text-xs font-light cursor-pointer"
                variants={itemVariants}
                whileHover={{ 
                  scale: 1.1, 
                  backgroundColor: "#f3f4f6",
                  boxShadow: "0 4px 15px rgba(0,0,0,0.1)"
                }}
                whileTap={{ scale: 0.95 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                {skill}
              </motion.span>
            ))}
          </motion.div>
          
          {/* Glowing Buttons */}
          <motion.div 
            className="flex flex-col sm:flex-row gap-3 sm:gap-4 pt-4 sm:pt-6 px-2 lg:px-0"
            variants={itemVariants}
          >
            <motion.button
              onClick={scrollToAbout}
              className="group relative px-5 sm:px-6 py-3 bg-gray-900 text-white rounded-2xl font-light text-sm overflow-hidden w-full sm:w-auto"
              whileHover={{ 
                scale: 1.05,
                boxShadow: "0 10px 30px rgba(0,0,0,0.3)"
              }}
              whileTap={{ scale: 0.95 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600 opacity-0"
                whileHover={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
              />
              <span className="relative z-10 flex items-center justify-center">
                View Portfolio
                <motion.div
                  animate={{ y: [0, 3, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <ArrowDown className="ml-2 w-4 h-4" />
                </motion.div>
              </span>
            </motion.button>
            
            <motion.button 
              onClick={downloadCV}
              className="group px-5 sm:px-6 py-3 border border-gray-300 text-gray-700 rounded-2xl font-light text-sm relative overflow-hidden w-full sm:w-auto"
              whileHover={{ 
                scale: 1.05,
                borderColor: "#6b7280",
                backgroundColor: "#f9fafb"
              }}
              whileTap={{ scale: 0.95 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-gray-100 to-gray-200 opacity-0"
                whileHover={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
              />
              <span className="relative z-10 flex items-center justify-center">
                <motion.div
                  whileHover={{ y: -2 }}
                  transition={{ duration: 0.2 }}
                >
                  <Download className="w-4 h-4 mr-2" />
                </motion.div>
                Download CV
              </span>
            </motion.button>
          </motion.div>
        </motion.div>
        
        {/* Photo Side with Enhanced Animations */}
        <motion.div
          initial={{ x: 100, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.8, type: "spring" }}
          className="relative group order-1 lg:order-2"
        >
          <div className="relative w-full max-w-[280px] sm:max-w-[320px] lg:max-w-[400px] h-[320px] sm:h-[380px] lg:h-[480px] mx-auto">
            {/* Animated Gradient Background */}
            <motion.div 
              className="absolute -inset-3 sm:-inset-4 lg:-inset-6 rounded-3xl blur-2xl opacity-70"
              animate={{
                background: [
                  "linear-gradient(45deg, rgba(229,231,235,0.3), rgba(156,163,175,0.2), rgba(107,114,128,0.3))",
                  "linear-gradient(45deg, rgba(107,114,128,0.3), rgba(229,231,235,0.3), rgba(156,163,175,0.2))",
                  "linear-gradient(45deg, rgba(156,163,175,0.2), rgba(107,114,128,0.3), rgba(229,231,235,0.3))"
                ]
              }}
              transition={{ duration: 4, repeat: Infinity }}
              whileHover={{ opacity: 0.9, scale: 1.02 }}
            />
            
            {/* Photo Container with Hover Effects */}
            <motion.div 
              className="relative w-full h-full bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl overflow-hidden shadow-2xl border border-gray-200/50"
              whileHover={{ 
                scale: 1.02,
                rotateY: window.innerWidth >= 1024 ? 5 : 0,
                rotateX: window.innerWidth >= 1024 ? 5 : 0,
                boxShadow: "0 25px 50px rgba(0,0,0,0.15)"
              }}
              transition={{ type: "spring", stiffness: 300 }}
              style={{
                transformStyle: "preserve-3d",
                perspective: "1000px"
              }}
            >
              <img 
                src="/lovable-uploads/1d9870d7-0d2c-48da-b2a2-e1966500cec3.png" 
                alt="Vignesh VM - Frontend Developer" 
                className="w-full h-full object-cover"
              />
              
              {/* Animated Overlay */}
              <motion.div 
                className="absolute inset-0 bg-gradient-to-t from-gray-900/5 via-transparent to-transparent"
                whileHover={{ opacity: 0.8 }}
                transition={{ duration: 0.3 }}
              />
              
              {/* Professional Badge with Animation */}
              <motion.div 
                className="absolute bottom-3 sm:bottom-4 left-3 sm:left-4 right-3 sm:right-4"
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 1.2, duration: 0.6 }}
              >
                <motion.div 
                  className="bg-white/90 backdrop-blur-sm rounded-xl p-2 sm:p-3 shadow-lg"
                  whileHover={{ scale: 1.05, y: -2 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <div className="flex items-center space-x-2">
                    <motion.div 
                      className="w-2 h-2 bg-green-500 rounded-full"
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    />
                    <span className="text-xs font-medium text-gray-800">Available for Projects</span>
                  </div>
                </motion.div>
              </motion.div>
            </motion.div>
            
            {/* Floating Accent Elements - Hidden on smaller screens */}
            <motion.div
              className="absolute -top-3 -right-3 w-5 h-5 sm:w-6 sm:h-6 bg-gray-300 rounded-lg shadow-lg hidden sm:block"
              animate={{
                y: [0, -10, 0],
                rotate: [0, 180, 360],
                scale: [1, 1.1, 1]
              }}
              transition={{
                duration: 6,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
            
            <motion.div
              className="absolute -bottom-2 -left-2 w-4 h-4 bg-gray-400 rounded-md shadow-md hidden sm:block"
              animate={{
                x: [0, 10, 0],
                y: [0, -5, 0],
                rotate: [0, -180, -360]
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 1
              }}
            />
          </div>
        </motion.div>
      </div>
      
      {/* Enhanced Scroll Indicator */}
      <motion.div 
        className="absolute bottom-4 sm:bottom-6 left-1/2 transform -translate-x-1/2"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 2, duration: 0.6 }}
      >
        <motion.div 
          className="flex flex-col items-center space-y-1 sm:space-y-2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <span className="text-xs text-gray-400 font-light">Scroll to explore</span>
          <motion.div 
            className="w-4 sm:w-5 h-6 sm:h-8 border border-gray-400 rounded-full flex justify-center opacity-60"
            whileHover={{ scale: 1.1, opacity: 1 }}
          >
            <motion.div 
              className="w-1 h-2 bg-gray-500 rounded-full mt-1"
              animate={{ y: [0, 8, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />
          </motion.div>
        </motion.div>
      </motion.div>
    </section>
  );
};

export default Hero;
