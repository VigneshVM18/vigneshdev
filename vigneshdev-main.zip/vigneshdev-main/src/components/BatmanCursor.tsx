
import React from 'react';

interface BatmanCursorProps {
  x: number;
  y: number;
}

const BatmanCursor: React.FC<BatmanCursorProps> = ({ x, y }) => {
  return (
    <div
      className="fixed pointer-events-none z-50 transition-all duration-75 ease-out"
      style={{
        left: x - 24,
        top: y - 24,
        transform: 'scale(1)',
      }}
    >
      <svg
        width="48"
        height="48"
        viewBox="0 0 120 120"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="drop-shadow-2xl"
      >
        {/* Outer glowing ring */}
        <circle 
          cx="60" 
          cy="60" 
          r="45" 
          fill="none" 
          stroke="#fbbf24" 
          strokeWidth="1" 
          opacity="0.2"
          className="animate-spin"
          style={{ animationDuration: '3s' }}
        />
        
        {/* Inner rotating ring */}
        <circle 
          cx="60" 
          cy="60" 
          r="35" 
          fill="none" 
          stroke="#60a5fa" 
          strokeWidth="0.5" 
          opacity="0.3"
          className="animate-spin"
          style={{ animationDuration: '2s', animationDirection: 'reverse' }}
        />
        
        {/* Gradient definitions */}
        <defs>
          <radialGradient id="batmanGradient" cx="50%" cy="40%" r="60%">
            <stop offset="0%" stopColor="#1f2937" />
            <stop offset="50%" stopColor="#374151" />
            <stop offset="100%" stopColor="#111827" />
          </radialGradient>
          
          <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
            <feMerge> 
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
          
          <filter id="shadow" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="2" dy="2" stdDeviation="3" floodColor="rgba(0,0,0,0.3)"/>
          </filter>
        </defs>
        
        {/* Main batman logo body */}
        <path
          d="M60 30C52 30 45 33 38 38C30 43 23 50 19 58C16 64 16 70 19 76C23 84 30 89 38 92C45 95 52 95 60 95C68 95 75 95 82 92C90 89 97 84 101 76C104 70 104 64 101 58C97 50 90 43 82 38C75 33 68 30 60 30Z"
          fill="url(#batmanGradient)"
          filter="url(#glow)"
          opacity="0.95"
        />
        
        {/* Batman logo details */}
        <path
          d="M60 35C55 35 50 37 45 40C40 43 35 48 32 54C30 58 30 62 32 66C35 71 40 74 45 76C50 78 55 78 60 78C65 78 70 78 75 76C80 74 85 71 88 66C90 62 90 58 88 54C85 48 80 43 75 40C70 37 65 35 60 35Z"
          fill="#4b5563"
          opacity="0.8"
          filter="url(#shadow)"
        />
        
        {/* Wing details with enhanced glow */}
        <path
          d="M19 70C16 74 19 80 25 83C31 86 38 85 42 81C38 78 34 75 31 70C28 65 22 67 19 70Z"
          fill="#1f2937"
          filter="url(#glow)"
        />
        <path
          d="M101 70C104 74 101 80 95 83C89 86 82 85 78 81C82 78 86 75 89 70C92 65 98 67 101 70Z"
          fill="#1f2937"
          filter="url(#glow)"
        />
        
        {/* Center glowing core */}
        <circle cx="60" cy="58" r="4" fill="#fbbf24" opacity="0.9" className="animate-pulse" />
        <circle cx="60" cy="58" r="2" fill="#fff" opacity="1" />
        
        {/* Enhanced trailing particles */}
        <circle cx="25" cy="25" r="1.5" fill="#fbbf24" opacity="0.6" className="animate-ping" />
        <circle cx="95" cy="35" r="1" fill="#60a5fa" opacity="0.5" className="animate-ping" style={{ animationDelay: '0.3s' }} />
        <circle cx="85" cy="95" r="1.2" fill="#a855f7" opacity="0.4" className="animate-ping" style={{ animationDelay: '0.6s' }} />
        <circle cx="35" cy="85" r="0.8" fill="#10b981" opacity="0.5" className="animate-ping" style={{ animationDelay: '0.9s' }} />
        
        {/* Dynamic energy lines */}
        <path
          d="M40 45 L80 75"
          stroke="#fbbf24"
          strokeWidth="0.5"
          opacity="0.3"
          className="animate-pulse"
        />
        <path
          d="M80 45 L40 75"
          stroke="#60a5fa"
          strokeWidth="0.5"
          opacity="0.2"
          className="animate-pulse"
          style={{ animationDelay: '0.5s' }}
        />
      </svg>
      
      {/* Additional outer glow effect */}
      <div 
        className="absolute inset-0 bg-gradient-to-r from-yellow-400/10 via-blue-400/10 to-purple-400/10 rounded-full blur-xl animate-pulse"
        style={{ animationDuration: '2s' }}
      />
    </div>
  );
};

export default BatmanCursor;
