
import React, { useEffect, useState } from 'react';
import { Palette, Monitor, Wrench, Code, Smartphone, Zap } from 'lucide-react';

const Services = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const servicesSection = document.getElementById('services');
    if (servicesSection) {
      observer.observe(servicesSection);
    }

    return () => observer.disconnect();
  }, []);

  const services = [
    {
      title: 'UI/UX Design',
      icon: Palette,
      description: 'Creating intuitive and visually stunning user interfaces with modern design principles.',
      features: ['Wireframing', 'Prototyping', 'User Research', 'Design Systems']
    },
    {
      title: 'Website Development',
      icon: Monitor,
      description: 'Building responsive, high-performance websites that deliver exceptional user experiences.',
      features: ['Portfolio Sites', 'E-Commerce', 'Landing Pages', 'Custom Solutions']
    },
    {
      title: 'Website Maintenance',
      icon: Wrench,
      description: 'Ongoing support and optimization to keep your digital presence running smoothly.',
      features: ['Security Updates', 'Performance Optimization', 'Content Updates', 'Bug Fixes']
    },
    {
      title: 'Custom Development',
      icon: Code,
      description: 'Tailored front-end solutions designed specifically for your unique business needs.',
      features: ['React Applications', 'JavaScript Solutions', 'API Integration', 'Code Review']
    },
    {
      title: 'Responsive Design',
      icon: Smartphone,
      description: 'Modernizing websites with mobile-first design and enhanced user experiences.',
      features: ['Mobile-First Design', 'Cross-Browser Compatibility', 'Performance Optimization', 'SEO Enhancement']
    },
    {
      title: 'No-Code Development',
      icon: Zap,
      description: 'Rapid application development using modern no-code platforms for quick deployment.',
      features: ['Lovable', 'Webflow', 'Framer', 'Rapid Prototyping']
    }
  ];

  return (
    <section id="services" className="py-24 bg-gray-900 relative overflow-hidden">
      {/* Minimal background effects */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-gray-700/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-gray-800/5 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-8 relative z-10">
        <div className={`transform transition-all duration-1000 ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
        }`}>
          <div className="text-center mb-20">
            <h2 className="text-6xl md:text-7xl font-extralight text-white mb-6 tracking-tight">
              <span className="text-gray-400">Services</span>
            </h2>
            <div className="w-20 h-px bg-gray-500 mx-auto mb-8"></div>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto font-light">
              Comprehensive solutions to transform your digital vision into reality
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => {
              const IconComponent = service.icon;
              return (
                <div
                  key={service.title}
                  className={`group relative bg-gray-800/30 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50 hover:border-gray-600/50 transition-all duration-500 transform hover:-translate-y-2 hover:shadow-2xl ${
                    isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
                  }`}
                  style={{ transitionDelay: `${index * 150}ms` }}
                >
                  {/* Subtle hover overlay */}
                  <div className="absolute inset-0 bg-gray-700/10 opacity-0 group-hover:opacity-100 rounded-2xl transition-opacity duration-500"></div>
                  
                  <div className="relative z-10">
                    {/* Icon */}
                    <div className="w-16 h-16 bg-gray-700 rounded-xl flex items-center justify-center mb-8 transform group-hover:scale-110 transition-all duration-300 border border-gray-600">
                      <IconComponent className="w-8 h-8 text-gray-300" />
                    </div>
                    
                    <h3 className="text-xl font-light text-white mb-6 group-hover:text-gray-200 transition-colors duration-300">
                      {service.title}
                    </h3>
                    
                    <p className="text-gray-400 mb-8 leading-relaxed font-light">
                      {service.description}
                    </p>
                    
                    <ul className="space-y-3">
                      {service.features.map((feature) => (
                        <li key={feature} className="flex items-center text-sm text-gray-500 font-light">
                          <div className="w-1.5 h-1.5 bg-gray-500 rounded-full mr-3 flex-shrink-0"></div>
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
