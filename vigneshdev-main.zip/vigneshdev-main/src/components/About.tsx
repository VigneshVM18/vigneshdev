
import React from 'react';
import { motion, Variants } from 'framer-motion';
import { Code, Palette, Monitor, Lightbulb } from 'lucide-react';

const About = () => {
  // Properly typed animation variants
  const containerVariants: Variants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3
      }
    }
  };

  const itemVariants: Variants = {
    hidden: { y: 50, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring" as const,
        stiffness: 100,
        damping: 12
      }
    }
  };

  const skills = [
    { name: 'Frontend Development', level: 95, icon: Code, color: 'from-blue-500 to-cyan-500' },
    { name: 'UI/UX Design', level: 90, icon: Palette, color: 'from-purple-500 to-pink-500' },
    { name: 'Responsive Design', level: 92, icon: Monitor, color: 'from-green-500 to-emerald-500' },
    { name: 'Problem Solving', level: 88, icon: Lightbulb, color: 'from-orange-500 to-yellow-500' }
  ];

  return (
    <section className="py-24 bg-white relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 left-10 w-32 h-32 bg-blue-100 rounded-full blur-3xl opacity-30"></div>
        <div className="absolute bottom-20 right-10 w-40 h-40 bg-purple-100 rounded-full blur-3xl opacity-30"></div>
      </div>

      <div className="max-w-7xl mx-auto px-8 relative z-10">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          {/* Section Header */}
          <motion.div variants={itemVariants} className="text-center mb-16">
            <motion.div 
              className="flex items-center justify-center space-x-3 mb-6"
              whileHover={{ scale: 1.05 }}
            >
              <div className="w-12 h-0.5 bg-gray-400"></div>
              <span className="text-gray-500 text-sm font-light tracking-widest uppercase">About Me</span>
              <div className="w-12 h-0.5 bg-gray-400"></div>
            </motion.div>
            
            <motion.h2 
              className="text-4xl md:text-5xl font-thin text-gray-900 mb-6"
              variants={itemVariants}
            >
              Passionate Developer
            </motion.h2>
            
            <motion.p 
              className="text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed"
              variants={itemVariants}
            >
              I'm a dedicated frontend developer with a passion for creating beautiful, functional, and user-friendly web experiences. 
              With expertise in modern technologies and a keen eye for design, I transform ideas into digital reality.
            </motion.p>
          </motion.div>

          {/* Skills Grid */}
          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16"
            variants={containerVariants}
          >
            {skills.map((skill, index) => (
              <motion.div
                key={skill.name}
                variants={itemVariants}
                className="group relative"
                whileHover={{ y: -5 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100 h-full relative overflow-hidden">
                  {/* Animated background gradient */}
                  <motion.div
                    className={`absolute inset-0 bg-gradient-to-br ${skill.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300`}
                  />
                  
                  <div className="relative z-10">
                    <motion.div
                      className={`w-12 h-12 bg-gradient-to-br ${skill.color} rounded-xl flex items-center justify-center mb-4`}
                      whileHover={{ rotate: 360, scale: 1.1 }}
                      transition={{ duration: 0.6, type: "spring" }}
                    >
                      <skill.icon className="w-6 h-6 text-white" />
                    </motion.div>
                    
                    <h3 className="text-lg font-medium text-gray-900 mb-3">{skill.name}</h3>
                    
                    {/* Animated skill bar */}
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm text-gray-600">
                        <span>Proficiency</span>
                        <span>{skill.level}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                        <motion.div
                          className={`h-full bg-gradient-to-r ${skill.color} rounded-full`}
                          initial={{ width: 0 }}
                          whileInView={{ width: `${skill.level}%` }}
                          viewport={{ once: true }}
                          transition={{ duration: 1.5, delay: index * 0.2, ease: "easeOut" }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* Personal Touch */}
          <motion.div 
            variants={itemVariants}
            className="bg-gradient-to-br from-gray-50 to-white rounded-3xl p-8 md:p-12 shadow-xl border border-gray-100"
          >
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <motion.h3 
                  className="text-2xl md:text-3xl font-light text-gray-900 mb-6"
                  whileHover={{ scale: 1.02 }}
                >
                  My Journey
                </motion.h3>
                <motion.p 
                  className="text-gray-600 leading-relaxed mb-6"
                  variants={itemVariants}
                >
                  Started as a curious individual fascinated by technology, I've evolved into a skilled developer 
                  who believes in the power of clean code and exceptional user experiences. Every project is an 
                  opportunity to learn, grow, and create something meaningful.
                </motion.p>
                <motion.div 
                  className="flex flex-wrap gap-3"
                  variants={containerVariants}
                >
                  {['React', 'TypeScript', 'Tailwind CSS', 'Node.js', 'MongoDB'].map((tech, index) => (
                    <motion.span
                      key={tech}
                      variants={itemVariants}
                      className="px-4 py-2 bg-white text-gray-700 rounded-full text-sm font-medium shadow-sm border border-gray-200"
                      whileHover={{ 
                        scale: 1.05, 
                        backgroundColor: "#f8fafc",
                        boxShadow: "0 4px 15px rgba(0,0,0,0.1)"
                      }}
                      transition={{ type: "spring", stiffness: 300 }}
                    >
                      {tech}
                    </motion.span>
                  ))}
                </motion.div>
              </div>
              
              <motion.div 
                className="relative"
                whileHover={{ scale: 1.02 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl p-8 text-white">
                  <motion.div
                    animate={{ rotate: [0, 360] }}
                    transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                    className="w-16 h-16 border-2 border-white/30 rounded-full flex items-center justify-center mb-6"
                  >
                    <Code className="w-8 h-8" />
                  </motion.div>
                  <h4 className="text-xl font-medium mb-2">Always Learning</h4>
                  <p className="text-blue-100">
                    Staying updated with the latest technologies and best practices in web development.
                  </p>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;
