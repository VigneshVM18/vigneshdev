
import React, { useEffect, useState } from 'react';
import Hero from '../components/Hero';
import About from '../components/About';
import Services from '../components/Services';
import Experience from '../components/Experience';
import Education from '../components/Education';
import Contact from '../components/Contact';
import Navigation from '../components/Navigation';
import BatmanCursor from '../components/BatmanCursor';

const Index = () => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  useEffect(() => {
    // Add custom cursor styles to the document
    const style = document.createElement('style');
    style.textContent = `
      *,
      *::before,
      *::after {
        cursor: none !important;
      }
      
      a, button, [role="button"], input, textarea, select {
        cursor: none !important;
      }
      
      a:hover, button:hover, [role="button"]:hover {
        cursor: none !important;
      }
      
      @media (max-width: 768px) {
        *,
        *::before,
        *::after {
          cursor: auto !important;
        }
        
        a, button, [role="button"], input, textarea, select {
          cursor: pointer !important;
        }
      }
    `;
    document.head.appendChild(style);

    return () => {
      if (document.head.contains(style)) {
        document.head.removeChild(style);
      }
    };
  }, []);

  return (
    <div className="min-h-screen bg-white relative overflow-hidden">
      {/* Simple Clean Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-gray-50 via-white to-gray-100"></div>
      </div>

      {/* Batman Cursor - Hidden on mobile */}
      <div className="hidden md:block">
        <BatmanCursor x={mousePosition.x} y={mousePosition.y} />
      </div>

      {/* Navigation */}
      <Navigation />

      {/* Content with proper spacing for fixed nav */}
      <div className="relative z-10">
        <section id="home" className="min-h-screen pt-16">
          <Hero />
        </section>
        <section id="about" className="min-h-screen pt-8 sm:pt-12 lg:pt-16">
          <About />
        </section>
        <section id="services" className="min-h-screen pt-8 sm:pt-12 lg:pt-16">
          <Services />
        </section>
        <section id="experience" className="min-h-screen pt-8 sm:pt-12 lg:pt-16">
          <Experience />
        </section>
        <section id="education" className="min-h-screen pt-8 sm:pt-12 lg:pt-16">
          <Education />
        </section>
        <section id="contact" className="min-h-screen pt-8 sm:pt-12 lg:pt-16">
          <Contact />
        </section>
      </div>
    </div>
  );
};

export default Index;
